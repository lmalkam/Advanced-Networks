/*
Parallel Processors Assignment-1
Program 1: Multiply Matrices
Name: Kothuri Satya Sai Karthik
Roll No.: 177230

System Specifications:
Processor: Intel® Core™ i7-4500U CPU @ 1.80GHz × 4
L1 cache: 32KiB
L2 cache: 256KiB
L3 cache: 4MiB
Main Memory: 8GiB (4GiB SODIMM DDR3 x 2)
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define n 1000

double A[n][n], B[n][n], C[n][n];

//initialize matrices with random values
void init()
{
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            A[i][j] = rand();
            B[i][j] = rand();
        }
    } 
}

//mutiply matrices in O(n^3)
void multiply()
{
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            C[i][j] = 0;
            for(int k = 0; k < n; k++)
                C[i][j] += A[i][k] * B[k][j];
        }
    }
}

int main()
{
    srand(time(0)); //set seed to current time
    clock_t t1, t2, t3;
    t1 = clock();
    init();
    t2 = clock();
    multiply();
    t3 = clock();
    double init_time, mult_time, tot_time;
    init_time = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
    mult_time = ((double) (t3 - t2)) / CLOCKS_PER_SEC;
    tot_time = ((double) (t3 - t1)) / CLOCKS_PER_SEC;
    printf("Initialization time: %f seconds\n", init_time);
    printf("Multiplication time: %f seconds\n", mult_time);
    printf("Total time: %f seconds\n", tot_time);
}

/*
Observed Average times over 5 runs:
Initialization time: 0.0358392 seconds
Multiplication time: 8.2661606 seconds
Total time: 8.3019998 seconds
*/