/*
Parallel Processors Assignment-1
Program 3: Dijkstra's Single Source Shortest Path Algorithm
Name: Kothuri Satya Sai Karthik
Roll No.: 177230

System Specifications:
Processor: Intel® Core™ i7-4500U CPU @ 1.80GHz × 4
L1 cache: 32KiB
L2 cache: 256KiB
L3 cache: 4MiB
Main Memory: 8GiB (4GiB SODIMM DDR3 x 2)
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define n 1000
#define inf 9999

int G[n][n];

//initialize undirected graph with approximately n(n - 1) / 4 edges
void init()
{
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (rand() % 2)
                G[i][j] = G[j][i] = rand() % 100 + 1;
}
//dijkstra's algorithm
void dijkstra()
{

    int cost[n][n], dist[n], pred[n];
    int vis[n], count, mindist, nextnode, i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (G[i][j] == 0)
                cost[i][j] = inf;
            else
                cost[i][j] = G[i][j];
        }
    }
    for (i = 0; i < n; i++)
    {
        dist[i] = cost[0][i];
        pred[i] = 0;
        vis[i] = 0;
    }
    dist[0] = 0;
    vis[0] = 1;
    count = 1;
    while (count < n - 1)
    {
        mindist = inf;
        for (i = 0; i < n; i++)
        {
            if (dist[i] < mindist && !vis[i])
            {
                mindist = dist[i];
                nextnode = i;
            }
        }
        vis[nextnode] = 1;
        for (i = 0; i < n; i++)
        {
            if (!vis[i])
            {
                if (mindist + cost[nextnode][i] < dist[i])
                {
                    dist[i] = mindist + cost[nextnode][i];
                    pred[i] = nextnode;
                }
            }
        }
        count++;
    }
}

int main()
{
    srand(time(0)); //set seed to current time
    int runs = 10;
    double t[3];
    for (int i = 0; i < runs; i++)
    {
        t[0] += (double)clock() / CLOCKS_PER_SEC;
        init();
        t[1] += (double)clock() / CLOCKS_PER_SEC;
        dijkstra();
        t[2] += (double)clock() / CLOCKS_PER_SEC;
    }
    double init_time, sssp_time, tot_time;
    init_time = ((double)(t[1] - t[0])) / runs;
    sssp_time = ((double)(t[2] - t[1])) / runs;
    tot_time = ((double)(t[2] - t[0])) / runs;
    printf("Initialization time: %f seconds\n", init_time);
    printf("Dijkstra's Algorithm time: %f seconds\n", sssp_time);
    printf("Total time: %f seconds\n", tot_time);
}

/*
Observed Average times over 10 runs:
Initialization time: 0.012603 seconds
Dijkstra's Algorithm time: 0.012559 seconds
Total time: 0.025162 seconds
*/