/*
Parallel Processors Assignment-1
Program 3: Solve System of Linear Algebraic Equations with Gaussian Elimination
Name: Kothuri Satya Sai Karthik
Roll No.: 177230

System Specifications:
Processor: Intel® Core™ i7-4500U CPU @ 1.80GHz × 4
L1 cache: 32KiB
L2 cache: 256KiB
L3 cache: 4MiB
Main Memory: 8GiB (4GiB SODIMM DDR3 x 2)
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define n 1000

double A[n][n], X[n], B[n], Xtemp[n];

//initialize matrix and vector with random values
void init()
{
    //to generate a consistent system of equations find constants based on a solution
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            A[i][j] = rand() + 1; //to avoid zeroes
        Xtemp[i] = rand();
    }
    for(int i = 0; i < n; i++)
    {
        B[i] = 0;
        for(int j = 0; j < n; j++)
            B[i] += A[i][j] * Xtemp[j];
    }
}

//gaussian elimination in O(n^3)
void gauss()
{
    for(int i = 0; i < n; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            double fact = A[j][i] / A[i][i];
            for(int k = i; k < n; k++)
                A[j][k] -= fact * A[i][k];
        }
    }
}

//back-substitution in O(n^2)
void back_sub()
{
    for(int i = n - 1; i >= 0; i--)
    {
        X[i] = B[i] / A[i][i];
        for(int j = i - 1; j >= 0; j--)
            B[j] -= X[i] * A[j][i];
    }
}

//verify the answer generated
int verify()
{
    for(int i = 0; i < n; i++)
        if(abs(Xtemp[i] - X[i]) > 1)
            return 0;
    return 1;
}

int main()
{
    srand(time(0)); //set seed to current time
    int runs = 5;
    double t[5];
    for(int i = 0; i < runs; i++)
    {
        t[0] += (double)clock() / CLOCKS_PER_SEC;
        init();
        t[1] += (double)clock() / CLOCKS_PER_SEC;
        gauss();
        t[2] += (double)clock() / CLOCKS_PER_SEC;
        back_sub();
        t[3] += (double)clock() / CLOCKS_PER_SEC;
        int val = verify();
        t[4] += (double)clock() / CLOCKS_PER_SEC;
        if(val)
            printf("Passed\n");
        else printf("Failed\n");
    }
    double init_time, gaus_time, back_time, ver_time, tot_time;
    init_time = ((double) (t[1] - t[0])) / runs;
    gaus_time = ((double) (t[2] - t[1])) / runs;
    back_time = ((double) (t[3] - t[2])) / runs;
    ver_time = ((double) (t[4] - t[3])) / runs;
    tot_time = ((double) (t[4] - t[0])) / runs;
    printf("Initialization time: %f seconds\n", init_time);
    printf("Gaussian Elimination time: %f seconds\n", gaus_time);
    printf("Back Substitution time: %f seconds\n", back_time);
    printf("Verification time: %f seconds\n", ver_time);
    printf("Total time: %f seconds\n", tot_time);
}

/*
Observed Average times over 5 runs:
Initialization time: 0.017818 seconds
Gaussian Elimination time: 1.265457 seconds
Back Substitution time: 0.002936 seconds
Verification time: 0.000005 seconds
Total time: 1.286217 seconds
*/