/*
Parallel Processors Assignment-1
Program 2: Multiply Matrix with Vector
Name: Kothuri Satya Sai Karthik
Roll No.: 177230

System Specifications:
Processor: Intel® Core™ i7-4500U CPU @ 1.80GHz × 4
L1 cache: 32KiB
L2 cache: 256KiB
L3 cache: 4MiB
Main Memory: 8GiB (4GiB SODIMM DDR3 x 2)
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define n 1000

double A[n][n], B[n], C[n];

//initialize matrix and vector with random values
void init()
{
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            A[i][j] = rand();
        B[i] = rand();
    } 
}

//mutiply matrix and vector in O(n^2)
void multiply()
{
    for(int i = 0; i < n; i++)
    {
        C[i] = 0;
        for(int j = 0; j < n; j++)
            C[i] += B[j] * A[j][i];
    }
}

int main()
{
    srand(time(0)); //set seed to current time
    clock_t t1, t2, t3;
    t1 = clock();
    init();
    t2 = clock();
    multiply();
    t3 = clock();
    double init_time, mult_time, tot_time;
    init_time = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
    mult_time = ((double) (t3 - t2)) / CLOCKS_PER_SEC;
    tot_time = ((double) (t3 - t1)) / CLOCKS_PER_SEC;
    printf("Initialization time: %f seconds\n", init_time);
    printf("Multiplication time: %f seconds\n", mult_time);
    printf("Total time: %f seconds\n", tot_time);
}

/*
Observed Average times over 5 runs:
Initialization time: 0.0220248 seconds
Multiplication time: 0.0065514 seconds
Total time: 0.0285762 seconds
*/