/*
Parallel Processors Assignment-1
Program 3: Floyd-Warshall All Pairs Shortest Path Algorithm
Name: Kothuri Satya Sai Karthik
Roll No.: 177230

System Specifications:
Processor: Intel® Core™ i7-4500U CPU @ 1.80GHz × 4
L1 cache: 32KiB
L2 cache: 256KiB
L3 cache: 4MiB
Main Memory: 8GiB (4GiB SODIMM DDR3 x 2)
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define n 1000
#define inf 9999

int G[n][n], APS[n][n];

//initialize undirected graph with approximately n(n - 1) / 4 edges
void init()
{
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (rand() % 2)
                G[i][j] = G[j][i] = rand() % 100 + 1;
}

//floyd-warshall algorithm
void apsp()
{
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            APS[i][j] = G[i][j];
    for(int k = 0; k < n; k++)
        for(int i = 0; i < n; i++)
            for(int j = 0; j < n; j++)
                if(APS[i][k] + APS[k][j] < APS[i][j])
                    APS[i][j] = APS[i][k] + APS[k][j];
}

int main()
{
    srand(time(0)); //set seed to current time
    int runs = 5;
    double t[3];
    for (int i = 0; i < runs; i++)
    {
        t[0] += (double)clock() / CLOCKS_PER_SEC;
        init();
        t[1] += (double)clock() / CLOCKS_PER_SEC;
        apsp();
        t[2] += (double)clock() / CLOCKS_PER_SEC;
    }
    double init_time, apsp_time, tot_time;
    init_time = ((double)(t[1] - t[0])) / runs;
    apsp_time = ((double)(t[2] - t[1])) / runs;
    tot_time = ((double)(t[2] - t[0])) / runs;
    printf("Initialization time: %f seconds\n", init_time);
    printf("Floyd-Warshall Algorithm time: %f seconds\n", apsp_time);
    printf("Total time: %f seconds\n", tot_time);
}

/*
Observed Average times over 5 runs:
Initialization time: 0.013626 seconds
Floyd-Warshall Algorithm time: 3.401744 seconds
Total time: 3.415370 seconds
*/