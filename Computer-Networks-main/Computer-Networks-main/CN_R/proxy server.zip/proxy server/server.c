#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>
#include <poll.h>
#include <signal.h>
#include <fcntl.h>
#include <pthread.h>

struct my_msg {
    int cli_ind;
    char data[256];
};

//all the vars needed
const int servers = 2;
int pfd, sfd[5], portno[5], nsfds[100], cs = 0, serv_needed[100], clilen = 0, th_num[5] = {0, 1, 2, 2, 2}, connected[100];
struct sockaddr_in serv_addr[5], cli_addr, cli_addr_list[100], proxy_addr;
pthread_t tid[5];
char buff[256];

void *virtual(void *args) {
    int *num = args;
    int serv_num = *num;
    printf("Thread %d started executing\n", serv_num);
    struct my_msg msg;
    while(1) {
        struct pollfd fds[10];
        fds[0].fd = sfd[serv_num];
        fds[0].events = POLLIN;
        int ctr = 1;
        for(int i = 0; i < cs; i++) {
            if(serv_needed[i] == serv_num && connected[i]) {
                fds[ctr].fd = nsfds[i];
                fds[ctr].events = POLLIN;
                ctr++;
            }
        }
        int r = poll(fds, ctr, 1000);
        if(r < 0) {
            continue;
        }
        if(fds[0].revents & POLLIN) {
            recv(sfd[serv_num], &msg, sizeof(msg), 0);
            if(strlen(msg.data) == 0) {
                printf("Fatal error service %d exited. Closing", serv_num + 1);
                exit(1);
            }
            int ind = msg.cli_ind;
            send(nsfds[ind], msg.data, 255, 0);
        }
        for(int i = 1; i < ctr; i++) {
            if(fds[i].revents & POLLIN) {
                recv(fds[i].fd, msg.data, 255, 0);
                if(strlen(msg.data) == 0) {
                    connected[i] = 0;
                    continue;
                }
                for(int j = 0; j < cs; j++) {
                    if(fds[i].fd == nsfds[j]) {
                        msg.cli_ind = j;
                        break;
                    }
                }
                send(sfd[serv_num], &msg, sizeof(msg), 0);
            }
        }
    }

}

int main() {

    //initialize proxy server address
    proxy_addr.sin_addr.s_addr = INADDR_ANY;
    proxy_addr.sin_family = AF_INET;
    proxy_addr.sin_port = htons(51720);

    //create socket
    if((pfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        exit(1);
    }

    //setsockopt to reuse the same address
    int opt = 1;
    if((setsockopt(pfd, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt))) < 0) {
        perror("setsockopt");
        exit(1);
    }

    //bind address to socket fd
    if(bind(pfd, (struct sockaddr*)&proxy_addr, sizeof(proxy_addr)) < 0) {
        perror("bind");
        exit(1);
    }

    if(listen(pfd, 5) < 0) {
        perror("listen");
        exit(1);
    }
    //initialize server threads
    for(int i = 0; i < servers; i++) {
        int len = sizeof(serv_addr[i]);
        if((sfd[i] = accept(pfd, (struct sockaddr*)&serv_addr[i], &len)) < 0) {
            perror("accept client");
        }
        portno[i] = ntohs(serv_addr[i].sin_port);
        th_num[i] = i;
        pthread_create(&tid[i], NULL, virtual, (void*)&th_num[i]);
    }

    while(1) {
        int len = sizeof(cli_addr_list[cs]);
        if((nsfds[cs] = accept(pfd, (struct sockaddr*)&cli_addr_list[cs], &len)) < 0) {
            perror("accept client");
        }
        else {
            
            int r = recv(nsfds[cs], buff, 255, 0);
            if(r > 0) {
                int num = atoi(buff);
                serv_needed[cs] = num;
                connected[cs] = 1;
                cs++;
            }
            else if(r < 0) {
                perror("first recv");
            }
        }
    }
}