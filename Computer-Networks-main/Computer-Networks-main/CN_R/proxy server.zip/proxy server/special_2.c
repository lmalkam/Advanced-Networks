#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <poll.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>

#define h_addr h_addr_list[0]

struct my_msg {
    int cli_ind;
    char data[256];
};

//portno should be known prior
int sfd, portno = 51720;
char *name = "localhost"; //name can be ipv4 address(leave it as localhost if local chatting)
struct sockaddr_in serv_addr, cli_addr;//server_details address
struct hostent *server_details;//server_details details

//handler function to close opened fds when signalled
void hdfn(int signo) {
    close(sfd);
    signal(SIGINT, SIG_DFL);
    raise(SIGINT);
}

int myConnect() {
    if(connect(sfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        perror("Error connecting");
        return -1;
    }

    return 0;
}

int main() {
    signal(SIGINT, hdfn);

    //gets server details by name of the server
    server_details = gethostbyname(name);
    if(server_details == NULL) {
        perror("Invalid host name");
        exit(1);
    }

    if((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        exit(1);
    }

    //initialize serv_addr
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);//htons adjusts byte ordering

    //copy server address from server_details
    bcopy((char *) server_details->h_addr, 
         (char *) &serv_addr.sin_addr.s_addr, 
         server_details->h_length);

    int f = myConnect();
    if(f == -1) {
        printf("Could not connect terminating...\n");
        exit(1);
    }

    //buff for other clients buff1 for keyboard
    struct my_msg buff;

    while(1) {
        recv(sfd, &buff, sizeof(buff), 0);
        printf("Recieved %s from %d\n", buff.data, buff.cli_ind);
        for(int i = 0; i < strlen(buff.data); i++) {
            buff.data[i] = toupper(buff.data[i]);
        }
        send(sfd, &buff, sizeof(buff), 0);
    }
}

