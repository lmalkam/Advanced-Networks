#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

int main() {
    while(1) {
        char buff[100];
        buff[0] = '\0';
        read(0, buff, 100);
        for(int i = 0; i < strlen(buff); i++) {
            buff[i] = tolower(buff[i]);
        }
        write(1, buff, strlen(buff) + 1);
    }
}