#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main() {
    char p2fo[] = "p2fo";
    while(1) {
        int wfd = open(p2fo, O_WRONLY);
        char buff[] = "Msg from p2";
        write(wfd, buff, (int)strlen(buff) + 1);
        close(wfd);
        sleep(2 + rand() % 5);
    }
}