#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    while(1) {
        printf("Msg from p1");
        fflush(stdout);
        sleep(2 + rand() % 5);
    }
}