#include<bits/stdc++.h>
#include<sys/poll.h>
#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<iostream>
#include<semaphore.h>
#include<cctype>
#include<sys/stat.h>
using namespace std;

int port;
int totalCabs;
int sfd;
int DPORT;

int sfdMaker(int port){
    struct sockaddr_in AT;
    int sfd;
	if((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		perror("sfd fail");
		return 0;
	}
	int opt = 1;
	if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        	perror("setsockopt");
        	return 0;
    }
	AT.sin_family = AF_INET;
	AT.sin_addr.s_addr = INADDR_ANY;
	AT.sin_port = htons(port);
	if(bind(sfd,(struct sockaddr*) &AT, sizeof(AT)) < 0){
		perror("bind failed");
		return 0;
	}
	if(listen(sfd,3) < 0){
		perror("listen failed");
		return 0;
	}
    return sfd;
}

int main(int argc, char* argv[]){
    totalCabs = atoi(argv[2]);
    if(argv[1][0] == 'M')port = 10000;
    else port = 11000;
    DPORT = port;
    cout << port << endl;
    sfd = sfdMaker(port);

    int nsfd;
    sockaddr_in clien;
    socklen_t cliensize = sizeof(clien);
    nsfd = accept(sfd,(sockaddr*)&clien,&cliensize);
    send(nsfd,&totalCabs,sizeof(int),0);
    char location[1000];
    while(read(nsfd,location,sizeof(location))){
        cout << location << endl;
        int portToPass = ++DPORT;
        char ptp[100] = "9999";
        // sprintf(ptp,"%d",portToPass);
        char driver[] = "Chacha";
        int c = fork();
        cout << c << endl;
        if(c < 0){
            perror("fork fail : ");
            exit(0);
        }
        if(!c){
            close(nsfd);
            close(sfd);
            char* pname[] = {"./T",location,driver,ptp,NULL};
            execv(pname[0],pname);
        }else{
            send(nsfd,ptp,strlen(ptp)+1,0);
        }
    }
    return 0;
}